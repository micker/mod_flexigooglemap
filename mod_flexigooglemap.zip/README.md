# mod_flexigooglemap
Module to display all item in category like a marker with adress field
